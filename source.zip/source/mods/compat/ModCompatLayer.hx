package mods.compat;

#if sys
import sys.FileSystem;
import sys.io.File;
#end
import haxe.Json;
import funkin.data.Song;
import mods.compat.ModFormat;
import mods.compat.ModFormat.ModFormatDetector;
import mods.compat.VSliceConverter;

using StringTools;

/**
 * ModCompatLayer
 * ─────────────────────────────────────────────────────────────────────────────
 * Single entry-point for ALL mod compatibility.
 * Handles charts, characters (JSON + XML), and stages for Psych and Codename.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * INTEGRATION — 3 one-line changes in the engine
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 1. Song.hx — replace the last line of loadFromJson():
 *      return mods.compat.ModCompatLayer.loadChart(rawJson);
 *
 * 2. Character.hx — inside loadCharacterData(), replace:
 *      characterData = cast Json.parse(content);
 *    with:
 *      characterData = cast mods.compat.ModCompatLayer.loadCharacter(content, character);
 *
 *    ALSO update the path lookup above it from:
 *      var jsonPath = Paths.characterJSON(character);
 *    to:
 *      var jsonPath = mods.compat.ModCompatLayer.resolveCharacterPath(character);
 *
 * 3. Stage.hx — inside loadStage(), replace:
 *      stageData = cast Json.parse(file);
 *    with:
 *      stageData = cast mods.compat.ModCompatLayer.loadStage(file, stageName);
 *
 *    ALSO update the path lookup before it from:
 *      var file:String = Paths.getText(Paths.stageJSON(stageName));
 *    to:
 *      var file:String = mods.compat.ModCompatLayer.readStageFile(stageName);
 *      if (file == null) { loadDefaultStage(); return; }
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * What is auto-converted
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Format          Charts  Characters (JSON)  Characters (XML)  Stages (JSON)
 *  ─────────────   ──────  ─────────────────  ────────────────  ─────────────
 *  Psych 0.6/0.7     ✓           ✓                  —               ✓
 *  Codename (CNE)    ✓           ✓                  ✓               ✓
 *  Cool Engine       ✓           ✓                  —               ✓  (native)
 *
 * NOT supported (no workaround possible):
 *   - Psych Lua scripts (.lua files)
 *   - Codename .hxs stage scripts (different API — falls back to default stage)
 *   - Custom engine-specific UI scripts
 *
 * Audio paths are resolved automatically via ModPathResolver:
 *   Psych/CNE:  songs/name/Inst.ogg      →  found and used directly
 *   Cool:       songs/name/song/Inst.ogg →  found and used directly
 */
class ModCompatLayer
{
	// ─── Charts ───────────────────────────────────────────────────────────────

	/**
	 * Parses a chart JSON string → SwagSong (Cool Engine format).
	 * Drop-in replacement for Song.parseJSONshit(rawJson).
	 *
	 * @param rawJson      Contenido crudo del JSON del chart.
	 * @param difficulty   Nombre de dificultad (para convertidores que necesitan saberlo).
	 * @param chartFilePath  Path físico al archivo (para que VSliceConverter pueda
	 *                       buscar el archivo de metadata separado).
	 */
	public static function loadChart(rawJson:String, ?difficulty:String = 'hard',
	                                 ?chartFilePath:String = null):SwagSong
	{
		final fmt = ModFormatDetector.detectFromChartJson(rawJson);
		trace('[ModCompatLayer] Chart format: $fmt');
		return switch (fmt)
		{
			case ModFormat.PSYCH_ENGINE:    PsychConverter.convertChart(rawJson, difficulty);
			case ModFormat.CODENAME_ENGINE: CodenameConverter.convertChart(rawJson, difficulty);
			case ModFormat.VSLICE_ENGINE:   VSliceConverter.convertChart(rawJson, difficulty, chartFilePath);
			default:
				final _root:Dynamic = Json.parse(rawJson);
				// root.song can be a nested chart object OR just a song-name String
				// (flat Psych charts). Only use it as the chart object when it's not a String.
				final _rootSong:Dynamic = _root.song;
				cast (_rootSong != null && !Std.isOfType(_rootSong, String) ? _rootSong : _root);
		};
	}

	// ─── Characters ───────────────────────────────────────────────────────────

	/**
	 * Resolves the correct character file path for a given character name,
	 * trying all engine-specific folder layouts.
	 *
	 * Use this INSTEAD OF Paths.characterJSON(character).
	 * Falls back to Paths.characterJSON() if the mod resolver finds nothing.
	 */
	public static function resolveCharacterPath(name:String):String
	{
		// Try mod-specific layouts first (handles Codename's data/characters/)
		final modPath = ModPathResolver.characterFile(name);
		if (modPath != null) return modPath;
		// Fallback to standard Cool/Psych layout via Paths
		return Paths.characterJSON(name);
	}

	/**
	 * Parses character file content → Cool Engine CharacterData (Dynamic).
	 * Handles JSON (Cool/Psych/Codename) and XML (Codename) automatically.
	 *
	 * Drop-in replacement for Json.parse(content) in Character.loadCharacterData().
	 */
	public static function loadCharacter(content:String, charName:String):Dynamic
	{
		final fmt = ModFormatDetector.detectFromCharContent(content);
		trace('[ModCompatLayer] Character "$charName" format: $fmt');

		// XML content → Codename XML converter
		if (content != null && content.ltrim().charAt(0) == '<')
			return CodenameXmlConverter.convertCharacter(content, charName);

		return switch (fmt)
		{
			case ModFormat.PSYCH_ENGINE:    PsychConverter.convertCharacter(content, charName);
			case ModFormat.CODENAME_ENGINE: CodenameConverter.convertCharacter(content, charName);
			// V-Slice: formato propio con "assetPath", "renderType", "healthIcon", etc.
			case ModFormat.VSLICE_ENGINE:   VSliceConverter.convertCharacter(content, charName);
			default:              Json.parse(content);
		};
	}

	// ─── Stages ───────────────────────────────────────────────────────────────

	/**
	 * Reads and returns the raw stage file content for a given stage name.
	 * Tries all engine-specific locations.
	 *
	 * Returns null if:
	 *   - No file found at all
	 *   - File is a Codename .hxs script (unsupported — caller should use default stage)
	 *
	 * Use this INSTEAD OF reading Paths.stageJSON() directly.
	 */
	public static function readStageFile(stageName:String):Null<String>
	{
		#if sys
		// 1. Try mod-specific layouts
		final modPath = ModPathResolver.stageFile(stageName);
		if (modPath != null)
		{
			// .hxs = Codename HScript stage — can't parse as JSON, use default
			if (modPath.endsWith('.hxs'))
			{
				trace('[ModCompatLayer] Stage "$stageName" is a Codename .hxs script — using default stage.');
				return null;
			}
			return File.getContent(modPath).trim();
		}

		// 2. Fall back to standard Cool Engine path
		// Paths.stageJSON devuelve un path relativo (sin assets/) pensado para
		// Paths.getText, que internamente llama a resolve() y añade el prefijo.
		final coolContent = Paths.getText(Paths.stageJSON(stageName));
		if (coolContent != null && coolContent.length > 0)
			return coolContent;
		#else
		// Non-sys: use standard Paths
		final p = Paths.stageJSON(stageName);
		if (openfl.utils.Assets.exists(p))
			return openfl.utils.Assets.getText(p);
		#end
		return null;
	}

	/**
	 * Parses a stage JSON string → Cool Engine StageData (Dynamic).
	 * Auto-detects Psych / Codename / Cool formats.
	 *
	 * Drop-in replacement for Json.parse(file) in Stage.loadStage().
	 */
	public static function loadStage(rawJson:String, stageName:String):Dynamic
	{
		final fmt = ModFormatDetector.detectFromStageJson(rawJson);
		trace('[ModCompatLayer] Stage "$stageName" format: $fmt');
		return switch (fmt)
		{
			case ModFormat.PSYCH_ENGINE:    PsychStageConverter.convertStage(rawJson, stageName);
			case ModFormat.CODENAME_ENGINE: CodenameStageConverter.convertStage(rawJson, stageName);
			default:              Json.parse(rawJson);
		};
	}

	// ─── Audio path helpers ───────────────────────────────────────────────────

	/**
	 * Resolves the Inst.ogg path for a song, trying both audio layouts.
	 * Use this INSTEAD OF Paths.inst(song) when a mod might be Psych/Codename.
	 *
	 * Returns the standard Paths.inst() result as fallback.
	 */
	public static function resolveInst(song:String):String
	{
		final modPath = ModPathResolver.inst(song);
		return modPath ?? Paths.inst(song);
	}

	/**
	 * Resolves the Voices.ogg path for a song.
	 * Tries split vocals (Psych 0.7+) first, then the combined file.
	 */
	public static function resolveVoices(song:String):String
	{
		final modPath = ModPathResolver.voices(song);
		return modPath ?? Paths.voices(song);
	}

	/**
	 * Returns the player (BF) voice track path for Psych 0.7+ split-vocal mods.
	 * Falls back to resolveVoices() if no split file exists.
	 */
	public static function resolveVoicesPlayer(song:String):String
	{
		final split = ModPathResolver.voicesPlayer(song);
		if (split != null) return split;
		return resolveVoices(song);
	}

	/**
	 * Returns the opponent (Dad) voice track path for Psych 0.7+ split-vocal mods.
	 * Falls back to resolveVoices() if no split file exists.
	 */
	public static function resolveVoicesOpponent(song:String):String
	{
		final split = ModPathResolver.voicesOpponent(song);
		if (split != null) return split;
		return resolveVoices(song);
	}

	/** Returns true if the active mod has split vocals for the given song. */
	public static function hasSplitVocals(song:String):Bool
		return ModPathResolver.hasSplitVocals(song);

	// ─── Format queries ───────────────────────────────────────────────────────

	/** Returns the detected ModFormat of the currently active mod (cached). */
	public static function getActiveModFormat():ModFormat
	{
		final modId = ModManager.activeMod;
		return modId != null ? getModFormat(modId) : COOL_ENGINE;
	}

	/** Returns the detected ModFormat of any installed mod by ID (cached). */
	public static function getModFormat(modId:String):ModFormat
	{
		if (_fmtCache.exists(modId)) return _fmtCache.get(modId);
		#if sys
		final fmt = ModFormatDetector.detectFromFolder('${ModManager.MODS_FOLDER}/$modId');
		_fmtCache.set(modId, fmt);
		trace('[ModCompatLayer] Mod "$modId" → $fmt');
		return fmt;
		#else
		return COOL_ENGINE;
		#end
	}

	/** Clears the format detection cache. Call after installing/removing mods. */
	public static function clearCache():Void _fmtCache.clear();

	// ─── Mod Freeplay + Story songs ──────────────────────────────────────────

	/**
	 * Escanea todos los mods habilitados en busca de semanas en formato
	 * Psych Engine y las convierte al formato ModSongsInfo de Cool Engine.
	 *
	 * Cubre el formato real de Psych 0.6/0.7:
	 *   data/weeks/myweek.json  →  {songs:[["name","icon",[R,G,B]],...],
	 *                               weekCharacters:["","bf",""],
	 *                               hideFreeplay, hideStoryMode,
	 *                               hiddenUntilUnlocked, startUnlocked,
	 *                               freeplayColor:[R,G,B], storyName, weekName}
	 *
	 * Cada semana devuelta tiene:
	 *   • hideFreeplay  → si es true, FreeplayState la omite
	 *   • showInStoryMode[] → si todo es false, StoryMenuState la omite
	 *
	 * Llamar desde loadSongsData() de FreeplayState Y StoryMenuState justo
	 * después de parsear el songList.json base, y hacer push a songsWeeks.
	 */
	public static function getModSongsInfo():Array<ModSongsInfo>
	{
		final result:Array<ModSongsInfo> = [];

		#if sys
		for (mod in mods.ModManager.installedMods)
		{
			if (!mod.enabled) continue;

			final base = '${mods.ModManager.MODS_FOLDER}/${mod.id}';
			var loaded = false;

			// ── A: data/freeplaySonglist.json (lista plana, sin Story Mode) ──
			for (fp in ['$base/data/freeplaySonglist.json', '$base/freeplaySonglist.json'])
			{
				if (!FileSystem.exists(fp)) continue;
				try
				{
					final raw:Dynamic = Json.parse(File.getContent(fp).trim());
					final list:Array<Dynamic> = (raw.songs != null && Std.isOfType(raw.songs, Array))
						? cast raw.songs
						: (Std.isOfType(raw, Array) ? cast raw : []);
					if (list.length == 0) continue;

					final week = _weekFromFreeplayList(list, mod.name);
					if (week.weekSongs.length > 0)
					{
						result.push(week);
						loaded = true;
						trace('[ModCompatLayer] Mod "${mod.id}" — ${week.weekSongs.length} songs via freeplaySonglist.json');
					}
				}
				catch (e:Dynamic) { trace('[ModCompatLayer] Error parsing $fp: $e'); }
				if (loaded) break;
			}
			if (loaded) continue;

			// ── B: data/weeks/*.json — formato real de Psych ─────────────────
			for (weekDir in ['$base/data/weeks', '$base/weeks'])
			{
				if (!FileSystem.exists(weekDir) || !FileSystem.isDirectory(weekDir)) continue;

				final files = FileSystem.readDirectory(weekDir);
				files.sort((a, b) -> a < b ? -1 : 1);

				for (wf in files)
				{
					if (!wf.endsWith('.json')) continue;
					try
					{
						final w:Dynamic = Json.parse(File.getContent('$weekDir/$wf').trim());
						final week = _weekFromPsychWeekJson(w, mod.name);
						if (week.weekSongs.length > 0)
						{
							result.push(week);
							trace('[ModCompatLayer] Mod "${mod.id}" — week "${week.weekName}" (${week.weekSongs.length} songs) from $wf');
						}
					}
					catch (e:Dynamic) { trace('[ModCompatLayer] Error parsing $weekDir/$wf: $e'); }
				}
				break; // primer directorio válido
			}
			if (loaded) continue;

			// ── C: V-Slice — data/songs.json o data/levels/*.json ────────────
			// V-Slice (Funkin' official) organiza las canciones en:
			//   data/songs.json → lista de IDs de canciones disponibles
			//   data/songs/{id}/{id}-metadata.json → metadatos de cada canción
			//   data/levels/{id}.json → "levels" (semanas) con lista de canciones
			//
			// Primero intentamos leer levels (equivalente a weeks) para preservar
			// agrupación. Si no hay levels, creamos una semana única con todas las
			// canciones del metadata.
			for (levelDir in ['$base/data/levels', '$base/levels'])
			{
				if (!FileSystem.exists(levelDir) || !FileSystem.isDirectory(levelDir)) continue;
				final files = FileSystem.readDirectory(levelDir);
				files.sort((a, b) -> a < b ? -1 : 1);
				for (lf in files)
				{
					if (!lf.endsWith('.json')) continue;
					try
					{
						final lv:Dynamic = Json.parse(File.getContent('$levelDir/$lf').trim());
						final week = _weekFromVSliceLevel(lv, mod.name, base);
						if (week.weekSongs.length > 0)
						{
							result.push(week);
							loaded = true;
							trace('[ModCompatLayer] Mod "${mod.id}" — V-Slice level "${week.weekName}" (${week.weekSongs.length} songs) from $lf');
						}
					}
					catch (e:Dynamic) { trace('[ModCompatLayer] Error parsing V-Slice level $levelDir/$lf: $e'); }
				}
				if (loaded) break;
			}
			if (loaded) continue;

			// Si no hay levels, escanear data/songs.json para obtener IDs y cargar
			// cada metadata individualmente (todo en una "semana" única).
			for (songListPath in ['$base/data/songs.json', '$base/data/freeplaySongs.json'])
			{
				if (!FileSystem.exists(songListPath)) continue;
				try
				{
					final rawList:Dynamic = Json.parse(File.getContent(songListPath).trim());
					final week = _weekFromVSliceSongList(rawList, mod.name, base);
					if (week.weekSongs.length > 0)
					{
						result.push(week);
						loaded = true;
						trace('[ModCompatLayer] Mod "${mod.id}" — V-Slice songs list: ${week.weekSongs.length} songs');
					}
				}
				catch (e:Dynamic) { trace('[ModCompatLayer] Error parsing V-Slice songs list $songListPath: $e'); }
				if (loaded) break;
			}
		}
		#end

		trace('[ModCompatLayer] getModSongsInfo → ${result.length} week(s) from mods');
		return result;
	}

	// ─── Conversión interna ───────────────────────────────────────────────────

	/**
	 * Convierte un "level" de V-Slice (equivalente a una semana de Psych).
	 *
	 * Formato V-Slice data/levels/{id}.json:
	 * {
	 *   "version": "1.0.0",
	 *   "name": "Week 1",
	 *   "titleAsset": "week1",
	 *   "background": "menuBGBlue",
	 *   "songs": ["bopeebo", "fresh", "dadbattle"],
	 *   "difficulties": ["easy", "normal", "hard"],
	 *   "characters": { "bf": "bf", "dad": "dad", "gf": "gf" }
	 * }
	 */
	static function _weekFromVSliceLevel(lv:Dynamic, modFallback:String, modBase:String):ModSongsInfo
	{
		final songs:Array<String>     = [];
		final icons:Array<String>     = [];
		final colors:Array<String>    = [];
		final bpms:Array<Float>       = [];
		final showInStory:Array<Bool> = [];

		final weekName:String = (lv.name != null) ? Std.string(lv.name) : modFallback;

		// Lista de IDs de canciones
		final songIds:Array<Dynamic> = (lv.songs != null && Std.isOfType(lv.songs, Array))
			? cast lv.songs : [];

		for (rawId in songIds)
		{
			final id:String = Std.string(rawId).toLowerCase().trim();
			if (id == '') continue;
			songs.push(id);

			// Intentar leer metadata para obtener icon/color/bpm
			var icon  = 'bf';
			var color = '0xFF9271FD';
			var bpm   = 100.0;
			_applyVSliceSongMeta(id, modBase, function(meta:Dynamic) {
				if (meta.healthIcon != null)      icon  = Std.string(meta.healthIcon.id ?? 'bf');
				if (meta.freeplayStyle != null)   color = _parseColor(meta.freeplayStyle.color ?? null);
				if (meta.timeChanges != null && Std.isOfType(meta.timeChanges, Array)) {
					final tc:Array<Dynamic> = cast meta.timeChanges;
					if (tc.length > 0) bpm = Std.parseFloat(Std.string(tc[0].bpm ?? 100.0));
				}
			});

			icons.push(icon);
			colors.push(color);
			bpms.push(bpm);
			showInStory.push(true);
		}

		// Dificultades
		var diffs:Array<String> = ['easy', 'normal', 'hard'];
		if (lv.difficulties != null && Std.isOfType(lv.difficulties, Array))
		{
			final rawDiffs:Array<Dynamic> = cast lv.difficulties;
			diffs = [for (d in rawDiffs) Std.string(d).trim()].filter(s -> s != '');
		}

		// Personajes de la semana (para la pantalla de Story Mode)
		var chars:Array<String> = ['', 'bf', ''];
		if (lv.characters != null)
		{
			final c:Dynamic = lv.characters;
			chars = [
				c.dad != null    ? Std.string(c.dad)    : '',
				c.bf != null     ? Std.string(c.bf)     : 'bf',
				c.gf != null     ? Std.string(c.gf)     : ''
			];
		}

		return {
			weekSongs:       songs,
			songIcons:       icons,
			color:           colors,
			bpm:             bpms,
			weekName:        weekName,
			weekCharacters:  chars,
			locked:          false,
			hideFreeplay:    false,
			showInStoryMode: showInStory,
			weekBackground:  lv.background != null ? Std.string(lv.background) : 'menuBGBlue',
			difficulties:    diffs
		};
	}

	/**
	 * Convierte el data/songs.json de V-Slice en una semana única para Freeplay.
	 *
	 * data/songs.json puede ser:
	 *   { "songs": ["bopeebo", "fresh"] }   ← lista de IDs
	 *   [ "bopeebo", "fresh" ]              ← array directo
	 *
	 * Para cada canción lee data/songs/{id}/{id}-metadata.json si existe.
	 */
	static function _weekFromVSliceSongList(raw:Dynamic, modFallback:String, modBase:String):ModSongsInfo
	{
		var songIds:Array<Dynamic> = [];
		if (Std.isOfType(raw, Array))
			songIds = cast raw;
		else if (raw.songs != null && Std.isOfType(raw.songs, Array))
			songIds = cast raw.songs;

		final songs:Array<String>   = [];
		final icons:Array<String>   = [];
		final colors:Array<String>  = [];
		final bpms:Array<Float>     = [];

		for (rawId in songIds)
		{
			final id:String = Std.string(rawId).toLowerCase().trim();
			if (id == '') continue;
			songs.push(id);

			var icon  = 'bf';
			var color = '0xFF9271FD';
			var bpm   = 100.0;
			_applyVSliceSongMeta(id, modBase, function(meta:Dynamic) {
				if (meta.healthIcon != null) icon = Std.string(meta.healthIcon.id ?? 'bf');
				if (meta.freeplayStyle != null) color = _parseColor(meta.freeplayStyle.color ?? null);
				if (meta.timeChanges != null && Std.isOfType(meta.timeChanges, Array)) {
					final tc:Array<Dynamic> = cast meta.timeChanges;
					if (tc.length > 0) bpm = Std.parseFloat(Std.string(tc[0].bpm ?? 100.0));
				}
			});

			icons.push(icon);
			colors.push(color);
			bpms.push(bpm);
		}

		return {
			weekSongs:       songs,
			songIcons:       icons,
			color:           colors,
			bpm:             bpms,
			weekName:        modFallback,
			weekCharacters:  ['', 'bf', ''],
			locked:          false,
			hideFreeplay:    false,
			showInStoryMode: [for (_ in songs) false]
		};
	}

	/**
	 * Intenta cargar el metadata de una canción V-Slice y llama al callback si lo encuentra.
	 *
	 * Rutas buscadas (V-Slice):
	 *   {modBase}/data/songs/{id}/{id}-metadata.json
	 *   {modBase}/data/songs/{id}/metadata.json
	 */
	static function _applyVSliceSongMeta(id:String, modBase:String, callback:Dynamic->Void):Void
	{
		#if sys
		for (p in [
			'$modBase/data/songs/$id/$id-metadata.json',
			'$modBase/data/songs/$id/metadata.json'
		]) {
			if (!FileSystem.exists(p)) continue;
			try {
				callback(Json.parse(File.getContent(p)));
				return;
			} catch (_:Dynamic) {}
		}
		#end
	}

	/**
	 * Convierte el formato real de semana de Psych 0.6/0.7:
	 *
	 *  {
	 *    "storyName":          "el es candel y esto es",
	 *    "weekName":           "candelweek",
	 *    "difficulties":       "Hard",
	 *    "hideFreeplay":       false,
	 *    "hideStoryMode":      false,
	 *    "hiddenUntilUnlocked":false,
	 *    "startUnlocked":      true,
	 *    "weekBackground":     "stage",
	 *    "freeplayColor":      [146, 113, 253],
	 *    "weekCharacters":     ["", "bf", ""],
	 *    "songs": [
	 *      ["Epic-Battle",        "candel",     [255, 73, 113]],
	 *      ["candelero",          "candel",     [255, 73, 113]],
	 *      ["Dusk-of-corruption", "evilcandel", [86, 173, 255]]
	 *    ]
	 *  }
	 */
	static function _weekFromPsychWeekJson(w:Dynamic, modFallback:String):ModSongsInfo
	{
		final songs:Array<String>       = [];
		final icons:Array<String>       = [];
		final colors:Array<String>      = [];   // color POR CANCIÓN (índice 2 de cada entry)
		final bpms:Array<Float>         = [];
		final showInStory:Array<Bool>   = [];

		// hideFreeplay / hideStoryMode
		final hideFreeplay:Bool   = w.hideFreeplay   == true;
		final hideStoryMode:Bool  = w.hideStoryMode  == true;

		// locked: true si hiddenUntilUnlocked=true O startUnlocked=false
		final startUnlocked:Bool  = w.startUnlocked == null ? true : (w.startUnlocked == true);
		final locked:Bool         = (w.hiddenUntilUnlocked == true) || !startUnlocked;

		// Color de semana para freeplay (freeplayColor)
		final weekFreeplayColor:String = _parseColorArr(w.freeplayColor);

		// Parsear canciones: cada entry es ["nombre", "icono", [R,G,B]]
		if (w.songs != null && Std.isOfType(w.songs, Array))
		{
			final list:Array<Dynamic> = cast w.songs;
			for (entry in list)
			{
				if (!Std.isOfType(entry, Array)) continue;
				final arr:Array<Dynamic> = cast entry;
				final name = arr.length > 0 ? Std.string(arr[0]).trim() : '';
				if (name == '') continue;

				songs.push(name);
				icons.push(arr.length > 1 && arr[1] != null ? Std.string(arr[1]) : 'bf');

				// Color por canción (arr[2]) — si no existe, usar freeplayColor
				colors.push(arr.length > 2 && arr[2] != null
					? _parseColor(arr[2])
					: weekFreeplayColor);

				bpms.push(100.0); // Psych weeks no incluyen BPM por canción
				showInStory.push(!hideStoryMode);
			}
		}

		// Nombre visible de la semana — preferir storyName, luego weekName
		final weekName:String = (w.storyName != null && Std.string(w.storyName).trim() != '')
			? Std.string(w.storyName)
			: (w.weekName != null ? Std.string(w.weekName) : modFallback);

		// weekCharacters: Psych guarda [leftOpponent, bf/center, rightGF]
		// Cool Engine espera lo mismo — pasamos directo
		var chars:Array<String> = ['', 'bf', ''];
		if (w.weekCharacters != null && Std.isOfType(w.weekCharacters, Array))
		{
			final wc:Array<Dynamic> = cast w.weekCharacters;
			// Rellenar posibles huecos con cadena vacía
			chars = [
				wc.length > 0 && wc[0] != null ? Std.string(wc[0]) : '',
				wc.length > 1 && wc[1] != null ? Std.string(wc[1]) : 'bf',
				wc.length > 2 && wc[2] != null ? Std.string(wc[2]) : ''
			];
		}

		// Parsear dificultades: Psych las guarda como string CSV "Easy,Normal,Hard"
		// BUG FIX: ignorar este campo dejaba al FreeplayState / StoryMode sin saber
		// qué dificultades soporta la semana, lo que rompía la selección de dificultad.
		var weekDiffs:Array<String> = ['Easy', 'Normal', 'Hard']; // default Psych
		if (w.difficulties != null)
		{
			final rawDiffs = Std.string(w.difficulties).trim();
			if (rawDiffs != '')
			{
				weekDiffs = [];
				for (d in rawDiffs.split(','))
				{
					final trimmed = d.trim();
					if (trimmed != '') weekDiffs.push(trimmed);
				}
			}
		}

		return {
			weekSongs:       songs,
			songIcons:       icons,
			color:           colors,
			bpm:             bpms,
			weekName:        weekName,
			weekCharacters:  chars,
			locked:          locked,
			hideFreeplay:    hideFreeplay,
			showInStoryMode: showInStory,
			weekBackground:  w.weekBackground != null ? Std.string(w.weekBackground) : 'stage',
			difficulties:    weekDiffs
		};
	}

	/**
	 * Convierte el formato freeplaySonglist.json de Psych:
	 *   [ {"name":"...", "icon":"...", "color":[R,G,B], "bpm":100} ]
	 * Estas canciones NUNCA aparecen en Story Mode (no tienen semana).
	 */
	static function _weekFromFreeplayList(list:Array<Dynamic>, modName:String):ModSongsInfo
	{
		final songs:Array<String>     = [];
		final icons:Array<String>     = [];
		final colors:Array<String>    = [];
		final bpms:Array<Float>       = [];

		for (entry in list)
		{
			final name:String = entry.name != null       ? Std.string(entry.name)
			                  : entry.songName != null   ? Std.string(entry.songName) : null;
			if (name == null || name.trim() == '') continue;

			songs.push(name);
			icons.push(entry.icon != null ? Std.string(entry.icon) : 'bf');
			colors.push(_parseColor(entry.color));
			bpms.push(entry.bpm != null ? Std.parseFloat(Std.string(entry.bpm)) : 100.0);
		}

		return {
			weekSongs:       songs,
			songIcons:       icons,
			color:           colors,
			bpm:             bpms,
			weekName:        modName,
			weekCharacters:  ['', 'bf', ''],
			locked:          false,
			hideFreeplay:    false,
			showInStoryMode: [for (_ in songs) false], // solo freeplay
			weekBackground:  'stage'
		};
	}

	// ─── Helpers de color ─────────────────────────────────────────────────────

	/**
	 * Convierte un campo "freeplayColor":[R,G,B] a string "0xFFRRGGBB".
	 * Devuelve "0xFF9271FD" (violeta) si el input es null o inválido.
	 */
	static inline function _parseColorArr(raw:Dynamic):String
		return _parseColor(raw);

	/**
	 * Convierte distintos formatos de color de Psych a "0xFFRRGGBB":
	 *   [R, G, B]     → "0xFFRRGGBB"
	 *   "RRGGBB"      → "0xFFRRGGBB"
	 *   "#RRGGBB"     → "0xFFRRGGBB"
	 *   null/inválido → "0xFF9271FD"  (violeta por defecto)
	 */
	static function _parseColor(raw:Dynamic):String
	{
		if (raw == null) return '0xFF9271FD';

		if (Std.isOfType(raw, Array))
		{
			final rgb:Array<Dynamic> = cast raw;
			if (rgb.length >= 3)
			{
				final r = StringTools.hex(Std.int(Std.parseFloat(Std.string(rgb[0]))) & 0xFF, 2);
				final g = StringTools.hex(Std.int(Std.parseFloat(Std.string(rgb[1]))) & 0xFF, 2);
				final b = StringTools.hex(Std.int(Std.parseFloat(Std.string(rgb[2]))) & 0xFF, 2);
				return '0xFF${r.toUpperCase()}${g.toUpperCase()}${b.toUpperCase()}';
			}
			return '0xFF9271FD';
		}

		var s = Std.string(raw).trim();
		if (s.startsWith('#'))  s = s.substr(1);
		if (s.toLowerCase().startsWith('0x')) s = s.substr(2);
		return switch (s.length)
		{
			case 6:  '0xFF${s.toUpperCase()}';
			case 8:  '0x${s.toUpperCase()}';
			default: '0xFF9271FD';
		};
	}

	static var _fmtCache:Map<String, ModFormat> = new Map();
}

/**
 * Estructura de semana compatible con SongsInfo (StoryMenuState/FreeplayState).
 * Campos extra respecto a SongsInfo nativa de Cool Engine:
 *   hideFreeplay   → la semana NO aparece en FreeplayState
 *   weekBackground → nombre del fondo para StoryMenuState (e.g. "stage")
 */
typedef ModSongsInfo =
{
	var weekSongs        : Array<String>;
	var songIcons        : Array<String>;
	var color            : Array<String>;
	var bpm              : Array<Float>;
	@:optional var weekName        : String;
	@:optional var weekCharacters  : Array<String>;
	@:optional var locked          : Bool;
	@:optional var showInStoryMode : Array<Bool>;
	// Campos exclusivos de mods
	@:optional var hideFreeplay    : Bool;
	@:optional var weekBackground  : String;
	// BUG FIX: Psych weeks.json tiene "difficulties":"Easy,Normal,Hard" — se mapea aquí
	@:optional var difficulties    : Array<String>;
}
